package Problem2;

public class TestDate {
    public static void main(String[] args) {
        Date d1 = new Date(6, 9, 2025);

        System.out.println(d1.toString());
    }
}
